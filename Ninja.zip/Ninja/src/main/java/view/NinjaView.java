/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author camper
 */

import java.util.Scanner;

public class NinjaView {

    private final Scanner scanner = new Scanner(System.in);

    public int showMenu() {
        System.out.println("\n--- Misiones y ninjas en Konoha ---");
        System.out.println("1. Crear un ninja.");
        System.out.println("2. Listar todos los ninjas junto con sus habilidades.");
//        System.out.println("2. View All");
//        System.out.println("3. Update");
//        System.out.println("4. Delete");
//        System.out.println("5. Exit");
        System.out.print("Seleccionar una opción: ");
        return scanner.nextInt();
    }
    
        public String getNombre() {
        System.out.print("Nombre del ninja: ");
        return scanner.next();
    }
    
        public String getRango() {
        System.out.print("Ingresa el rango (Aprendiz, soldado o maestro)\n ");
        return scanner.next();
    }
    
        public String getAldea() {
        System.out.print("Ingresa el nombre de la aldea: \n");
        return scanner.next();
    }
}

