/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author camper
 */

import controller.NinjaController;
import dao.NinjaDAO;
import view.NinjaView;

public class Main {
    public static void main(String[] args) {
        NinjaDAO dao = new NinjaDAO();
        NinjaView view = new NinjaView();
        NinjaController controller = new NinjaController(dao, view);
        controller.start();
    }
}
