/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author camper
 */

import model.Ninja;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NinjaDAO {
    
        private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/konoha";
        String user = "campus2023";
        String password = "campus2023";
        return DriverManager.getConnection(url, user, password);

    }

        
            // CREATE: crear un nuevo ninja
    public void addNinja(Ninja ninja) {
        String sql = "INSERT INTO Ninja (Nombre, Rango, Aldea) VALUES (?,?,?)";

        try (Connection conn = connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, ninja.getNombre());
            stmt.setString(2, ninja.getRango());
            stmt.setString(3, ninja.getAldea());

            stmt.executeUpdate();
            System.out.println("Ninja añadido con éxito");

        } catch (SQLException e) {
            System.out.println("Error al añadir un ninja: " + e.getMessage());
        }
    }
    
    // READ: Obtener todos los ninjas
    public List<Ninja> getAllNinja() {
        List<Ninja> ninjaList = new ArrayList<>();
        String sql = "SELECT ID, n.NOMBRE, h.NOMBRE, h.DESCRIPCION FROM NINJA n JOIN HABILIDAD h ON n.ID = h.ID_NINJA; ";

        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Ninja ninja = new Ninja(
                        rs.getInt("ID"),
                        rs.getString("NOMBRE"),
                        rs.getString("NOMBRE"),
                        rs.getString("DESCRIPCION")
                );
                ninjaList.add(ninja);
            }

        } catch (SQLException e) {
            System.out.println("Ocurrió un error al recuperar la lista de Ninjas: " + e.getMessage());
        }

        return ninjaList;
    }
}
