/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import dao.NinjaDAO;
import model.Ninja;
import view.NinjaView;

/**
 *
 * @author camper
 */
public class NinjaController {
    private final NinjaDAO dao;
    private final NinjaView view;

    public NinjaController(NinjaDAO dao, NinjaView view) {
        this.dao = dao;
        this.view = view;
    }

    public void start() {
        while (true) {
            int choice = view.showMenu();
            switch (choice) {
                case 1: // Añadir ninja
                    dao.addNinja(new Ninja(0, view.getNombre(), view.getRango(), view.getAldea()));
                    break;
                case 2: // Ninjas y sus habilidades
                    for (Ninja n : dao.getAllNinja()) {
                        System.out.println(n);
                    }
                    break;
//                case 2: // Misiones por ninja
//                    for (Ninja n : dao.getAllNinja()) {
//                        System.out.println(n);
//                    }
//                    break;

                case 3: // Exit
                    System.out.println("Hasta luego");
                    return;

                default:
                    System.out.println("Opción no válida. Intentar nuevamente");
            }
        }
    }
}
